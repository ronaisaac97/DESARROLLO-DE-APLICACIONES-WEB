const nombre = document.getElementById("nombre");
const correo = document.getElementById("correo");
const password = document.getElementById("password");
const confirmar = document.getElementById("confirmar");
const edad = document.getElementById("edad");
const enviar = document.getElementById("enviar");
const formulario = document.getElementById("formulario");

function mostrarError(input, mensaje) {
    const small = input.nextElementSibling;
    small.textContent = mensaje;
    input.classList.add("invalido");
    input.classList.remove("valido");
}

function mostrarValido(input) {
    const small = input.nextElementSibling;
    small.textContent = "";
    input.classList.add("valido");
    input.classList.remove("invalido");
}

function validarNombre() {
    if (nombre.value.length < 3) {
        mostrarError(nombre, "Debe tener al menos 3 caracteres");
        return false;
    }
    mostrarValido(nombre);
    return true;
}

function validarCorreo() {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(correo.value)) {
        mostrarError(correo, "Correo no válido");
        return false;
    }
    mostrarValido(correo);
    return true;
}

function validarPassword() {
    const regex = /^(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$/;
    if (!regex.test(password.value)) {
        mostrarError(password, "Mínimo 8 caracteres, un número y un símbolo");
        return false;
    }
    mostrarValido(password);
    return true;
}

function validarConfirmacion() {
    if (password.value !== confirmar.value || confirmar.value === "") {
        mostrarError(confirmar, "Las contraseñas no coinciden");
        return false;
    }
    mostrarValido(confirmar);
    return true;
}

function validarEdad() {
    if (edad.value < 18) {
        mostrarError(edad, "Debe ser mayor o igual a 18 años");
        return false;
    }
    mostrarValido(edad);
    return true;
}

function validarFormulario() {
    if (
        validarNombre() &&
        validarCorreo() &&
        validarPassword() &&
        validarConfirmacion() &&
        validarEdad()
    ) {
        enviar.disabled = false;
    } else {
        enviar.disabled = true;
    }
}

nombre.addEventListener("input", validarFormulario);
correo.addEventListener("input", validarFormulario);
password.addEventListener("input", validarFormulario);
confirmar.addEventListener("input", validarFormulario);
edad.addEventListener("input", validarFormulario);

formulario.addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Formulario enviado correctamente. Validación exitosa ✅");
});
