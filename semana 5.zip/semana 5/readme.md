# 🌟 Galería Interactiva - Caballeros del Zodiaco 🌟

Proyecto desarrollado para la Semana 5 de la asignatura Interacción Humano Computador.

## 🚀 Funcionalidades
- Agregar imágenes mediante URL
- Seleccionar imágenes con un clic
- Resaltar imagen seleccionada
- Eliminar imagen seleccionada
- Atajos de teclado (Enter y Delete)
- Diseño responsive con CSS Grid

## 🛠 Tecnologías
- HTML5
- CSS3
- JavaScript (DOM y eventos)

## 🌐 Publicación
El proyecto se encuentra publicado en GitHub Pages.

## ✨ Autor
Richard Oña