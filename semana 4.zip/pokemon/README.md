# 🌟 Mundo Pokémon - Bootstrap 5

Proyecto web responsivo creado con Bootstrap 5 y CSS3 avanzado.

## 🚀 Tecnologías usadas
- HTML5
- CSS3
- Bootstrap 5
- GitHub Pages

## 📂 Estructura
- index.html
- styles.css
- assets/img/

## 🌐 Despliegue
Proyecto publicado en GitHub Pages.

